rosservice call /turtlesim1/clear
rosservice call /turtlesim2/clear

