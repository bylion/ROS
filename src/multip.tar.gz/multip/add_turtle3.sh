rosservice call spawn 4 4 0.2 "turtle3"
